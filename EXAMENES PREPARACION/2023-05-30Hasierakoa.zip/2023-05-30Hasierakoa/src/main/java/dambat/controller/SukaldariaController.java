package dambat.controller;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ResourceBundle;

import dambat.App;
import dambat.model.DatuAtzipena;
import dambat.model.base.Bazkaria;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;

public class SukaldariaController implements Initializable {
  @FXML
  HBox hboxErroa;

  @FXML
  TextField tfEguna;
  @FXML
  TextField tfJana;
  @FXML
  TextField tfPrezioa;

  @FXML
  Label lbMezua;
  @FXML
  TableView<Bazkaria> tvBazkariak;

  @FXML
  TableColumn<Bazkaria, LocalDate> tcEguna;
  @FXML
  TableColumn<Bazkaria, String> tcJana;
  @FXML
  TableColumn<Bazkaria, Double> tcPrezioa;

  @Override
  public void initialize(URL arg0, ResourceBundle arg1) {

    hboxErroa.setSpacing(20);
    hboxErroa.setPadding(new Insets(20));

    //TableViewa kargatu
    //OSATU METODOA

  }

  /**
   * Metodo honek erabiltzaileak sartutako datueki Bazkaria objektua sortzen du eta DatuAtzipena klaseko
   * bazkariaGehitu metodoari deitzen dio zerrendan gehitzeko. 
   * Ondo gehitu bada, textfield-ak "garbitu" eta mezu bat (Ondo gehi...)
   * Bestela, beste mezu bat (Egun horretarako baz...)
   * Erabiltzaileak datu ezegokiak sartu dituen try-catch bidez kontrolatuko da.   * 
   * 
   * @throws IOException
   */
  @FXML
  void handleGehitu() throws IOException {
    //OSATU METODO HAU

  }

  @FXML
  void hasierara() throws IOException {
    App.setRoot("hasierakoa");
  }

  /**
   * Textfield guztiak garbitzen ditu.
   */
  public void garbitu() {
    //OSATU METODO HAU
  }
}
