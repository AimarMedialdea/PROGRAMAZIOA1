package dambat.model.base;

/** OSATU EZAZU KLASE HAU */

public class Hobariduna{

}
    

